#pragma once
#include<iostream>
#include <ctime>
using namespace std;
class Person
{
private:
	int id;
	long phone;
	char* name;
	char* gender;
	int dateOfBirth[3];
	char* email;
	char* bloodGroup;
public:
	Person();
	~Person();
	void setValues();
	void printValues()const;
	int findAge();
	void viewContacts()const;
};

