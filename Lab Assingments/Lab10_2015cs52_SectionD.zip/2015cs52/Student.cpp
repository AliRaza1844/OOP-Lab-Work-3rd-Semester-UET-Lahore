#include "Student.h"



Student::Student()
{
	registrationNo = new char[20];
}


Student::~Student()
{
	delete[]registrationNo;
}

void Student::getData()
{
	Person::setValues();
	cout << "\n Enter the registration number   :   ";
	cin>> registrationNo;
	cout << "\n Enter the cgpa of the student    :   ";
	cin >> cgpa;
	cout << "\n Student's year of study   :    ";
	cin >> yearOfStudy;
}

void Student::print() const
{
	Person::printValues();
	cout << "\n Registration number   :   " << registrationNo;
	cout << "\n CGPA of the student    :   " << cgpa;
	cout << "\n Student's year of study   :    " << yearOfStudy;
}

char * Student::findDegreeTitle()
{
	char* title=new char[10];
	int j = 0;
	for (int i = 0; i < strlen(registrationNo); i++)
	{
		if ((registrationNo[i] > 64 && registrationNo[i] < 91) || (registrationNo[i] > 96 && registrationNo[i] < 123))
			title[j++] = registrationNo[i];
	}

	return title;
}

char * Student::findSession()
{
	int i = 0 ;
	char* session = new char[4];
	while (registrationNo[i] > 47 && registrationNo[i] < 58)
	{
		session[i] = registrationNo[i];
		i++;
	}
	return session;
}

bool Student::findStudent(Student s_list[50],int no)
{
	for (int i = 0; i < no; i++)
		if (registrationNo == s_list[i].registrationNo)
			return true;
	return false;
}