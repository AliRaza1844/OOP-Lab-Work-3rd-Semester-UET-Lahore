#pragma once
#include"Person.h";
class Student:public Person
{
private:
	char* registrationNo;
	float cgpa;
	int yearOfStudy;
public:
	Student();
	~Student();
	void getData();
	void print()const;
	char* findDegreeTitle();
	char* findSession();
	bool findStudent(Student[],int);
};