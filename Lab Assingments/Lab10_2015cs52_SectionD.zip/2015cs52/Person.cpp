#include "Person.h"



Person::Person()
{
	name = new char[30];
	gender = new char[6];
	email = new char[40];
	bloodGroup = new char[4];
}

Person::~Person()
{
	delete[]name;
	delete[]gender;
	delete[]email;
	delete[]bloodGroup;
}

void Person::setValues()
{
	char temp;
	cout << " \n Name  :   ";
	cin >> name;
	cout << "\n Id   :   ";
	cin >> id;
	cout << " \nEnter Date of Birth with dashes  :   ";
	cin >> dateOfBirth[0];
	for (int i = 1; i < 3; i++)
	{
		cin >> temp;
		cin >> dateOfBirth[i];
	}
	cout << "\n Phone number   :   ";
	cin >> phone;
	cout << " \n Email Address  :   ";
	cin >> email;
	cout << "\n Gender   :   ";
	cin >> gender;
	cout << " \n Blood Group  :   ";
	cin >> bloodGroup;
}

void Person::printValues()const
{
	cout << " \n Name  :   "<<name;
	cout << "\n Id   :   "<<id;
	cout << " \n Date of Birth  :   " << dateOfBirth[0];
	for (int i = 0; i < 3; i++)
		cout << "-" << dateOfBirth[i];
	cout << "\n Phone number   :   " << phone;
	cout << " \n Email Address  :   " << email;
	cout << "\n Gender   :   " << gender;
	cout << " \n Blood Group  :   " << bloodGroup;
}

int Person::findAge()
{
	int currentYear,month,day;
		// current date/time based on current system
		//Number of sec since January 1,1970
		time_t now = time(0);
		tm *ltm = localtime(&now);

		currentYear=1900 + ltm->tm_year;
		month = 1 + ltm->tm_mon;
		day = ltm->tm_mday;
		if (month >= dateOfBirth[1] && day >= dateOfBirth[0])
			return currentYear - dateOfBirth[2];
		return currentYear - dateOfBirth[2] - 1;
}

void Person::viewContacts()const
{
	cout << "\n Phone  :   "<<phone;
	cout << "\n Email  :   " << email;
}
