#include "Teacher.h"



Teacher::Teacher()
{
	specification = new char[20];
}

Teacher::~Teacher()
{
	delete[]specification;
}

void Teacher::setData()
{
	char temp;
	Person::setValues();
	cout << "\n Enter the Date of joining with dashes   :   ";
	cin >> joiningDate[0];
	for (int i = 1; i < 3; i++)
	{
		cin >> temp;
		cin >> joiningDate[i];
	}
	cout << "\n Teacher's specialized subject is   :   ";
	cin >> specification;
}

void Teacher::Print() const
{
	Person::printValues();
	cout << "Date of joining   :   "<<joiningDate[0];
	for (int i = 1; i < 3; i++)
		cout << "-" << joiningDate[i];
}

int Teacher::findExperience()
{
	int currentYear, month, day;
	// current date/time based on current system
	//Number of sec since January 1,1970
	time_t now = time(0);
	tm *ltm = localtime(&now);

	currentYear = 1900 + ltm->tm_year;
	month = 1 + ltm->tm_mon;
	day = ltm->tm_mday;

	if (month >= joiningDate[1] && day >= joiningDate[0])
		return currentYear - joiningDate[2];
	return currentYear - joiningDate[2] - 1;

	return 0;
}

int Teacher::anualIncome()
{
	return salary * 12;
}
