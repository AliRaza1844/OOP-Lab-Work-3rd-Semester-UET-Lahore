#pragma once
#include"Person.h";
class Teacher:public Person
{
private:
	int salary;
	int joiningDate[3];
	char* specification;
public:
	Teacher();
	~Teacher();
	void setData();
	void Print()const;
	int findExperience();
	int anualIncome();
};

